﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace aplikacjaPowerShell
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private void przycisk1_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("clear.ps1"))
                Process.Start("powershell.exe", "-ExecutionPolicy Bypass -File clear.ps1");
            else
                MessageBox.Show("Brak pliku clear.ps1");
        }

        private void przycisk2_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("find_by_size.ps1"))
            {
                string od = txtOd.Text;
                string doMb = txtDo.Text;
                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-ExecutionPolicy Bypass -File \"find_by_size.ps1\" -FromMB {od} -ToMB {doMb}",
                    CreateNoWindow = false // pokazujemy konsolę, żeby można było kliknąć Enter
                };

                var proc = Process.Start(psi);
                proc.WaitForExit();  // poczekaj aż proces się zakończy, żeby plik był gotowy
                if (File.Exists("wyniki.txt"))
                {
                    txtWyniki.Text = File.ReadAllText("wyniki.txt", Encoding.UTF8);
                }
                else
                {
                    txtWyniki.Text = "Brak pliku wynikowego.";
                }
            }
            else
            {
                MessageBox.Show("Brak pliku find_by_size.ps1");
            }
        }

        private void przycisk3_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("install_apps.ps1"))
            {
                string idd = "";
                if (cVS.IsChecked == true) idd += "Microsoft.VisualStudio.2022.Community,";
                if (cVSCode.IsChecked == true) idd += "Microsoft.VisualStudioCode,";
                if (cSpotify.IsChecked == true) idd += "Spotify.Spotify,";
                if (cChrome.IsChecked == true) idd += "Google.Chrome,";
                if (cGit.IsChecked == true) idd += "Git.Git,";
                if (cGimp.IsChecked == true) idd += "GIMP.GIMP,";
                if (cInkscape.IsChecked == true) idd += "Inkscape.Inkscape,";
                if (cBrave.IsChecked == true) idd += "Brave.Brave,";

                idd = idd.TrimEnd(',');
                // przekazujemy parametry -Idd
                Process.Start("powershell.exe", $"-ExecutionPolicy Bypass -File install_apps.ps1 -Idd \"{idd}\"");
            }
            else
                MessageBox.Show("Brak pliku install_apps.ps1");
    }
    }
}